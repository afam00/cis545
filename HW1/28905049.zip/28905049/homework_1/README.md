# Homework 1: Data Wrangling and Persistence #

This is Homework 1 for CIS 545, Big Data Analytics.

